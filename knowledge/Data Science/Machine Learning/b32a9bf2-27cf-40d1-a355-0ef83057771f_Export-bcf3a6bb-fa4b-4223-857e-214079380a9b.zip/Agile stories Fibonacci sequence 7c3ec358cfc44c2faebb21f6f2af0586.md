# Agile stories Fibonacci sequence

Created: July 24, 2023 10:19 AM

1 = 2 hours

2 = 4 hours

3 = 1 day

5 = 2 days

8 = 3-4 days

13 = 5 days (This is okay for User Stories - re-think if this is for tasks)

21 = 10 days (Too long, split this story)

40 = Far too long. Run.